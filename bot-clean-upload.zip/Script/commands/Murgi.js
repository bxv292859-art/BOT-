// global state map to handle active loops and custom timeouts
if (!global.murgiLoopState) {
  global.murgiLoopState = {};
}

module.exports.config = {
  name: "murgi",
  version: "8.4.0",
  hasPermssion: 2, // 2 = শুধুমাত্র বট অ্যাডমিন (Bot Admin Only)
  credits: "Customized Advanced",
  description: "নির্দিষ্ট ব্যবহারকারীকে নোটিফাই ও কাস্টম মেসেজ লুপ পাঠানোর অ্যাডভান্সড কমান্ড",
  commandCategory: "admin",
  usages: "@mention [সংখ্যা] [কাস্টম মেসেজ] | off | info",
  cooldowns: 5
};

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, mentions } = event;

  // -------------------------------------------------------------
  // ১. INFO / HELP SECTION
  // -------------------------------------------------------------
  if (args[0] && args[0].toLowerCase() === "info") {
    const infoText = 
`🐔 ━━━━ [ MURGI COMMAND INFO ] ━━━━ 🐔

👑 Permission : Bot Admin Only
⚙️ Version    : 8.4.0

📖 ব্যবহার করার নিয়মাবলী:

🔹 ১. সাধারণ লুপ চালানো:
/murgi @mention
(ডিফল্ট ৫০টি র্যান্ডম মেসেজ পাঠাবে)

🔹 ২. নির্দিষ্ট সংখ্যা সেট করে:
/murgi @mention 10
(১০টি মেসেজ পাঠাবে)

🔹 ৩. কাস্টম মেসেজ দিয়ে:
/murgi @mention 15 গ্রুপে যোগ দিন!
(১৫টি 'গ্রুপে যোগ দিন!' মেসেজ পাঠাবে)

🔹 ৪. লুপ বন্ধ করতে:
/murgi off (বা stop)

🔹 ৫. তথ্য দেখতে:
/murgi info

🛡️ সিকিউরিটি সিস্টেম:
• ৫ মিনিটের অটো-টাইমআউট মেকানিজম অ্যাক্টিভ।
• মেমরি সেফটি ও ক্র্যাশ প্রটেকশন ইনক্লুডেড।

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

    return api.sendMessage(infoText, threadID, messageID);
  }

  // -------------------------------------------------------------
  // ২. STOP / OFF SECTION
  // -------------------------------------------------------------
  if (args[0] && (args[0].toLowerCase() === "off" || args[0].toLowerCase() === "stop")) {
    if (global.murgiLoopState[threadID]) {
      if (global.murgiLoopState[threadID].timeoutID) {
        clearTimeout(global.murgiLoopState[threadID].timeoutID);
      }
      global.murgiLoopState[threadID].active = false;
      delete global.murgiLoopState[threadID];
      
      return api.sendMessage("🛑 [MURGI SYSTEM]: মেসেজ লুপ সফলভাবে বন্ধ করা হয়েছে।", threadID, messageID);
    } else {
      return api.sendMessage("⚠️ [MURGI SYSTEM]: এই গ্রুপে বর্তমানে কোনো লুপ চালু নেই।", threadID, messageID);
    }
  }

  // -------------------------------------------------------------
  // ৩. MENTION & LOOP CHECK
  // -------------------------------------------------------------
  const mentionIDs = Object.keys(mentions);

  if (mentionIDs.length === 0) {
    return api.sendMessage("⚠️ [MURGI SYSTEM]: দয়া করে কাউকে মেনশন করুন। বিস্তারিত জানতে '/murgi info' লিখুন।", threadID, messageID);
  }

  if (global.murgiLoopState[threadID] && global.murgiLoopState[threadID].active) {
    return api.sendMessage("⚠️ [MURGI SYSTEM]: এই গ্রুপে অলরেডি একটি প্রসেস চলছে! থামাতে '/murgi off' লিখুন।", threadID, messageID);
  }

  const targetID = mentionIDs[0];
  const targetName = mentions[targetID];

  // -------------------------------------------------------------
  // ৪. CLEAN PARSING (FIXED DOUBLE MENTION ISSUE)
  // -------------------------------------------------------------
  // মেনশন টেক্সট সঠিকভাবে রিমুভ করা
  let cleanBody = event.body;
  if (targetName) {
    cleanBody = cleanBody.replace(`@${targetName}`, "").replace(targetName, "");
  }
  
  // কমান্ডের নাম বাদ দেওয়া
  let remainingArgs = cleanBody.split(/\s+/).filter(item => item.length > 0 && item.toLowerCase() !== "/murgi" && item.toLowerCase() !== "murgi");

  let count = 50;
  let customText = "";

  if (remainingArgs.length > 0) {
    const parsedCount = parseInt(remainingArgs[0]);
    if (!isNaN(parsedCount) && parsedCount > 0) {
      count = parsedCount > 100 ? 100 : parsedCount;
      customText = remainingArgs.slice(1).join(" ");
    } else {
      customText = remainingArgs.join(" ");
    }
  }

  // কাস্টম টেক্সট না দিলে এই লিস্ট থেকে মেসেজ যাবে
  const defaultTextList = [
    "অনলাইন সতর্কবার্তা!",
    "গ্রুপ রুলস মেনে চলবেন।",
    "আপনাকে নোটিফাই করা হলো।",
    "নিয়ম ভঙ্গ করবেন না।",
    "সবাই শান্ত থাকুন।"
  ];

  // -------------------------------------------------------------
  // ৫. AUTO-TIMEOUT SAFETY MECHANISM
  // -------------------------------------------------------------
  const safetyTimeout = setTimeout(() => {
    if (global.murgiLoopState[threadID]) {
      global.murgiLoopState[threadID].active = false;
      delete global.murgiLoopState[threadID];
      console.log(`[MURGI TIMEOUT]: Thread ${threadID} loop auto-cleared for safety.`);
    }
  }, 5 * 60 * 1000);

  global.murgiLoopState[threadID] = {
    active: true,
    timeoutID: safetyTimeout
  };

  api.sendMessage(`🚀 [ MURGI SYSTEM STARTED ]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 Target: ${targetName}
🔢 Total Messages: ${count}
⚙️ Custom Msg: ${customText ? `"${customText}"` : "Default Messages"}
🛑 Stop Command: /murgi off`, threadID);

  // -------------------------------------------------------------
  // ৬. MAIN LOOP EXECUTION
  // -------------------------------------------------------------
  for (let i = 0; i < count; i++) {
    if (!global.murgiLoopState[threadID] || !global.murgiLoopState[threadID].active) {
      break;
    }

    const messageText = customText 
      ? `${customText}` 
      : defaultTextList[Math.floor(Math.random() * defaultTextList.length)];

    const messageObject = {
      body: `${targetName} ${messageText} [${i + 1}/${count}]`,
      mentions: [{
        tag: targetName,
        id: targetID
      }]
    };

    try {
      await api.sendMessage(messageObject, threadID);
    } catch (error) {
      console.error("মেসেজ পাঠাতে সমস্যা হয়েছে:", error);
      break;
    }

    await delay(1000);
  }

  if (global.murgiLoopState[threadID]) {
    clearTimeout(global.murgiLoopState[threadID].timeoutID);
    delete global.murgiLoopState[threadID];
  }
};
