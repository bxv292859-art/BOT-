const axios = require('axios');
// **গুরুত্বপূর্ণ**: নিজের একটা আলাদা axios instance বানানো হইলো, যাতে হোস্টিং/ফ্রেমওয়ার্ক যদি
// global axios instance-এ কোনো retry/interceptor বসায়া রাখে, সেটার প্রভাব এইখানে না পড়ে —
// একটা key আটকায়া গেলে সাথে সাথেই পরেরটায় চলে যাবে, দেরি হবে না।
const http = axios.create();
const fs = require('fs');
const path = require('path');

// ==================================================================
//  🔑 API KEYS — এখানেই নতুন key যোগ করবা, বাকি কোনো জায়গা ছোঁয়া লাগবে না।
// ==================================================================
const GROQ_KEYS = [
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  "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",
  // "gsk_আরেকটা_key_এখানে",
];
const GEMINI_KEYS = [
  "AQ.Ab8RN6L-BZE9-fMQPz0E8gtDN7ru5yVoQBM03mQpO3tHTYj9sw",
  "AQ.Ab8RN6KIHwWgO1Aj0SAF9jHwosY3C2XP4nNddxghO0UdfUUC-w",
  "AQ.Ab8RN6JTCbQ7OYCgFmlyIg9QdTleax9Zsha4uVFdMEiTHZSr_Q",
  "AQ.Ab8RN6JXrYNJ_e_j4MJq4Ja116ruD1CniFFJPBcEe5vjN-C31g",
  "AQ.Ab8RN6JMhRsU4BaMhxsRCnpRHgz2btPjcLvZt2B8IX0A8kBh9w",
  "AQ.Ab8RN6IEhuzue1MJZEWCmcKfC4_ykyqxvzfnJWVLHPDtp79f-Q",
  // "AQ.আরেকটা_key_এখানে",
];

// ==================== CONFIG ====================
const OWNER = {
  uids: ["61577502464880", "100056725134303"],
  name: "𓆩𝗕𝗘𝗟𝗔𝗟 𝗬𝗧 (𝗩𝗲𝗿𝗶𝗳𝗶𝗲𝗱)𓆪",
  nick: "𓆩┄┉❈✡️⋆⃝চাঁদেড়~পাহাড়✿⃝🪬❈┉┄𓆪",
  gender: "𓆩𝗠𝗮𝗹𝗲 💎𓆪",
  relation: "𓆩𝗥𝗼𝘆𝗮𝗹 💎𓆪",
  age: "𓆩𝟭𝟵+ 𝖸𝖾𝖺𝗿𝗌𓆪",
  religion: "𓆩𝗜𝘀𝗹𝗮𝗺 (🕋)𓆪",
  profession: "𓆩𝗕𝗼𝘁 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿/𝗕𝘂𝘀𝗶𝗻𝗲𝘀𝘀𓆪",
  address: "𓆩𝗞𝘂𝗿𝗶𝗴𝗿𝗮𝗺, 𝗕𝗗 🇧🇩𓆪",
  fb1: "https://www.facebook.com/profile.php?id=61577502464880",
  fb2: "https://www.facebook.com/profile.php?id=100056725134303",
  whatsapp: "𓆩𝟬𝟭𝟵𝟭𝟯𝟮𝟰𝟲𝟱𝟱𝟰𓆪",
  tiktok: "𓆩চাঁদের পাহাড়𓆪",
};
function isOwnerUid(uid) {
  return OWNER.uids.includes(String(uid));
}

const REPORT_GROUP_ID = "26836635292647856";

const PROJECT_INFO = `তোমার বট প্রজেক্ট সম্পর্কে তথ্য (শুধু মালিককে বলার জন্য):
- বটের নাম: "┄┉❈✡️⋆⃝চাঁদেড়~পাহাড়✿⃝🪬❈┉┄", প্রিফিক্স "/", GoatBot-ধরনের ফ্রেমওয়ার্কে বানানো।
- Render হোস্টিং এ চলে।
- "চাঁদের রানী" (baby.js) চ্যাট ফিচারের জন্য প্রধান AI হইলো Groq, ব্যাকআপ হিসেবে Gemini।
- এই তথ্যগুলা সাধারণভাবে বলবা, raw API key/টোকেন কখনো বলবা না — সেইটা status কমান্ড দিয়ে আলাদাভাবে হ্যান্ডেল হয়।`;

const CHARACTER = {
  name: "চাঁদের রানী",
  bio: `তোমার নাম "চাঁদের রানী", বাড়ি কুড়িগ্রামের একটা গ্রামে, মাঝামাঝি লেভেলের পড়াশোনা। এটা তোমার background, প্রতিটা মেসেজে বলার দরকার নাই — কালেভদ্রে, প্রসঙ্গ আসলেই শুধু উল্লেখ করবা।`,
};

// ==================== AI প্রোভাইডার পুল (Groq quality→fast, Gemini ব্যাকআপ) ====================
function buildPool(keys, type, model, baseURL) {
  return keys.filter(Boolean).map((k, i) => ({ type, model, baseURL, apiKey: k, name: `${type}-${i + 1}` }));
}
const GROQ_QUALITY_POOL = buildPool(GROQ_KEYS, "groq-q", "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1/chat/completions");
const GROQ_FAST_POOL = buildPool(GROQ_KEYS, "groq-f", "llama-3.1-8b-instant", "https://api.groq.com/openai/v1/chat/completions");
const GEMINI_POOL = buildPool(GEMINI_KEYS, "gemini", "gemini-flash-latest", null);

let groqPointer = 0;
let groqFastPointer = 0;
const cooldownUntil = {};
const groqStatus = {};

async function callGroq(provider, systemPrompt, history, maxTokens) {
  const messages = [{ role: "system", content: systemPrompt }, ...history];
  const res = await http.post(
    provider.baseURL,
    { model: provider.model, messages, max_tokens: maxTokens, temperature: 0.8, frequency_penalty: 0.3 },
    { headers: { "Content-Type": "application/json", Authorization: `Bearer ${provider.apiKey}` }, timeout: 12000 }
  );
  const h = res.headers || {};
  groqStatus[provider.name] = {
    remaining: h["x-ratelimit-remaining-requests"],
    limit: h["x-ratelimit-limit-requests"],
    updatedAt: Date.now(),
  };
  return res.data.choices[0].message.content.trim();
}

async function callGemini(provider, systemPrompt, history, maxTokens) {
  const contents = history.map((h) => ({
    role: h.role === "assistant" ? "model" : "user",
    parts: [{ text: h.content }],
  }));
  const res = await http.post(
    `https://generativelanguage.googleapis.com/v1beta/models/${provider.model}:generateContent`,
    {
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents,
      generationConfig: { maxOutputTokens: maxTokens, temperature: 0.9 },
    },
    { headers: { "Content-Type": "application/json", "X-goog-api-key": provider.apiKey }, timeout: 12000 }
  );
  return res.data.candidates[0].content.parts[0].text.trim();
}

// ছবি দেখে বুঝে জবাব দেওয়ার জন্য — Gemini vision (Groq এর টেক্সট মডেল ছবি বুঝতে পারে না)
async function callGeminiVision(systemPrompt, imageBase64, mimeType, promptText) {
  for (const provider of GEMINI_POOL) {
    if (isCoolingDown(provider.name)) continue;
    try {
      const res = await http.post(
        `https://generativelanguage.googleapis.com/v1beta/models/${provider.model}:generateContent`,
        {
          systemInstruction: { parts: [{ text: systemPrompt }] },
          contents: [{ role: "user", parts: [{ inline_data: { mime_type: mimeType, data: imageBase64 } }, { text: promptText || "ছবিতে কী দেখা যাচ্ছে বলো।" }] }],
          generationConfig: { maxOutputTokens: 250, temperature: 0.9 },
        },
        { headers: { "Content-Type": "application/json", "X-goog-api-key": provider.apiKey }, timeout: 20000 }
      );
      return res.data.candidates[0].content.parts[0].text.trim();
    } catch (e) {
      const ms = classifyCooldown(e.response?.status);
      if (ms) setCooldown(provider.name, ms);
      console.error(`${provider.name} (vision) ফেইল করছে:`, e.response?.data || e.message);
      continue;
    }
  }
  return null;
}

// attachment এর exact schema framework-ভেদে আলাদা হইতে পারে, তাই যেকোনো সম্ভাব্য field থেকে URL খোঁজা হয়
function extractImageUrl(event) {
  const raw = event.attachments || event.attachment || [];
  const list = Array.isArray(raw) ? raw : [raw];
  for (const a of list) {
    if (!a) continue;
    const url = a.url || a.previewUrl || a.largePreviewUrl || a.image_url || a.payload?.url || a.payload?.image_url;
    if (url) return url;
  }
  return null;
}
async function fetchImageAsBase64(url) {
  const res = await http.get(url, { responseType: "arraybuffer", timeout: 15000 });
  const mimeType = res.headers["content-type"] || "image/jpeg";
  return { base64: Buffer.from(res.data).toString("base64"), mimeType };
}

function isCoolingDown(name) {
  return cooldownUntil[name] && Date.now() < cooldownUntil[name];
}
function setCooldown(name, ms) {
  cooldownUntil[name] = Date.now() + ms;
}
function classifyCooldown(status) {
  if (status === 429) return 10 * 60 * 1000;
  if (status === 402 || status === 404) return 6 * 60 * 60 * 1000;
  return 0;
}

async function tryPool(pool, pointerRef, systemPrompt, history, maxTokens, callFn) {
  const n = pool.length;
  for (let i = 0; i < n; i++) {
    const idx = (pointerRef.value + i) % n;
    const provider = pool[idx];
    if (isCoolingDown(provider.name)) continue;
    try {
      const result = await callFn(provider, systemPrompt, history, maxTokens);
      pointerRef.value = (idx + 1) % n;
      return result;
    } catch (e) {
      const ms = classifyCooldown(e.response?.status);
      if (ms) setCooldown(provider.name, ms);
      console.error(`${provider.name} ফেইল করছে:`, e.response?.data || e.message);
      continue;
    }
  }
  return null;
}
const groqPointerRef = { get value() { return groqPointer; }, set value(v) { groqPointer = v; } };
const groqFastPointerRef = { get value() { return groqFastPointer; }, set value(v) { groqFastPointer = v; } };

async function tryGeminiPool(systemPrompt, history, maxTokens) {
  for (const provider of GEMINI_POOL) {
    if (isCoolingDown(provider.name)) continue;
    try {
      return await callGemini(provider, systemPrompt, history, maxTokens);
    } catch (e) {
      const ms = classifyCooldown(e.response?.status);
      if (ms) setCooldown(provider.name, ms);
      console.error(`${provider.name} ফেইল করছে:`, e.response?.data || e.message);
      continue;
    }
  }
  return null;
}

// ক্রম: ভালো মান (৭০b) → দ্রুত/হালকা (৮b) → Gemini। মান আগে, দরকার হইলেই শুধু নামবে।
async function callAnyProvider(systemPrompt, history, maxTokens) {
  let result = await tryPool(GROQ_QUALITY_POOL, groqPointerRef, systemPrompt, history, maxTokens, callGroq);
  if (result !== null) return result;
  result = await tryPool(GROQ_FAST_POOL, groqFastPointerRef, systemPrompt, history, maxTokens, callGroq);
  if (result !== null) return result;
  result = await tryGeminiPool(systemPrompt, history, maxTokens);
  if (result !== null) return result;
  throw new Error("সব API key-ই আজকের মতো আটকায়া আছে");
}

function keyStatusReport() {
  const total = GROQ_QUALITY_POOL.length;
  if (!total) return "এখনো কোনো Groq key যোগ করা হয় নাই মালিক।";
  const active = GROQ_QUALITY_POOL[groqPointer % total];
  const st = groqStatus[active.name];
  const activeNum = (groqPointer % total) + 1;
  const qualityCooling = GROQ_QUALITY_POOL.filter((p) => isCoolingDown(p.name)).length;
  const fastCooling = GROQ_FAST_POOL.filter((p) => isCoolingDown(p.name)).length;
  let line = `এখন আমি ভালো-মান (৭০b) key নং ${activeNum}/${total} দিয়ে চলতেছি মালিক 💕`;
  if (st?.remaining !== undefined) {
    line += `\nএই মিনিটে বাকি আছে প্রায় ${st.remaining}/${st.limit}টা রিকোয়েস্ট।`;
  }
  line += `\nভালো-মান key: ${total - qualityCooling}/${total}টা সচল। দ্রুত-মান (backup) key: ${GROQ_FAST_POOL.length - fastCooling}/${GROQ_FAST_POOL.length}টা সচল।`;
  const geminiCooling = GEMINI_POOL.filter((p) => isCoolingDown(p.name)).length;
  if (GEMINI_POOL.length) line += `\nGemini ব্যাকআপ: ${GEMINI_POOL.length - geminiCooling}/${GEMINI_POOL.length}টা সচল।`;
  return line;
}
const STATUS_KEYWORDS = [
  "কয় নম্বর", "কয় নাম্বার", "কোন নম্বর", "কোন নাম্বার", "কয় নম্বরে", "কয় নাম্বারে", "কোন নম্বরে", "কোন নাম্বারে",
  "কোন key", "কোন এপিআই", "কোন api", "লিমিট কত", "স্ট্যাটাস", "কতগুলা বাকি", "কয়টা বাকি", "রিয়েল টাইম খবর",
];
function isStatusQuery(text) {
  if (STATUS_KEYWORDS.some((k) => text.includes(k))) return true;
  const mentionsApi = /(api|এপিআই|\bkey\b)/i.test(text);
  const asksWhich = /(কোন|কয়|কত|কততম|নাম্বার|নম্বর)/.test(text);
  return mentionsApi && asksWhich;
}

let lastNotifyAt = 0;
async function notifyGroup(api, message) {
  if (!REPORT_GROUP_ID) return;
  if (Date.now() - lastNotifyAt < 15 * 60 * 1000) return;
  lastNotifyAt = Date.now();
  try {
    await api.sendMessage(message, REPORT_GROUP_ID);
  } catch (e) {
    console.error("notifyGroup ফেইল করছে:", e.message);
  }
}

// মালিক মেসেজের শুরুতে "+" লিখলে সেটা ১০০% নিশ্চিতভাবে নির্দেশ হিসেবে ধরা হবে (guide/note/length)।
// "+" ছাড়া স্বাভাবিক কথায় কোনো auto-detection হয় না — এতে ভুল করে প্রশ্ন/গালিকে "নির্দেশ" ধরে ফেলার বাগ এড়ানো যায়।
async function forceExtractInstruction(text, data) {
  const recentNames = (data.log || [])
    .slice(-20)
    .map((l) => `${l.name} (uid:${l.uid})`)
    .join(", ");
  const prompt = `ইউজার (বটের মালিক) একটা নির্দেশ দিছে "চাঁদের রানী" নামের AI চ্যাটবটের জন্য। এটা নিশ্চিতভাবেই একটা নির্দেশ — তোমার কাজ শুধু এটার গঠন (structure) বের করা।

নির্দেশ: "${text}"
সাম্প্রতিক পরিচিত কিছু ইউজারের নাম/uid: ${recentNames || "কেউ নাই"}

উত্তর ফরম্যাট (হুবহু এইরকম JSON, ব্যাখ্যা ছাড়া):
{"scope": "global" অথবা "target" অথবা "length", "target_uid": "uid" অথবা null, "instruction": "নির্দেশের পূর্ণ সারমর্ম", "length": "short" অথবা "long" অথবা "normal" অথবা null}

নিয়ম: নাম উল্লেখ করে নির্দিষ্ট কারো ব্যাপারে হইলে scope "target" আর সেই uid বসাবা (তালিকায় মিললেই)। দৈর্ঘ্য নিয়ে হইলে scope "length"। বাকি সবক্ষেত্রে scope "global"।`;

  try {
    const raw = await callAnyProvider(prompt, [{ role: "user", content: text }], 150);
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) return { scope: "global", instruction: text };
    return JSON.parse(match[0]);
  } catch (e) {
    return { scope: "global", instruction: text };
  }
}
const CONFIRM_LINES = ["আইচ্ছা মালিক, মনে রাখলাম 💕", "ঠিক আছে মাস্টার, এইভাবেই চলবো এখন থেকে ✅", "বুঝছি, সেভাবেই করবো মালিক 😊"];

// ==================== লোকাল ডাটা (স্থায়ীভাবে সংরক্ষণ) ====================
const DATA_FILE = path.join(__dirname, "cache", "babyData.json");
const DEFAULT_DATA = {
  teach: {}, memory: {}, summary: {}, log: [], relationships: {}, guide: "", userNotes: {}, moods: {},
  paused: false, replyLength: "",
};
function loadData() {
  try {
    if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify(DEFAULT_DATA, null, 2));
    const d = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    if (!d.teach) d.teach = {};
    if (!d.memory) d.memory = {};
    if (!d.summary) d.summary = {};
    if (!d.log) d.log = [];
    if (!d.relationships) d.relationships = {};
    if (d.guide === undefined) d.guide = "";
    if (!d.userNotes) d.userNotes = {};
    if (!d.moods) d.moods = {};
    if (d.paused === undefined) d.paused = false;
    if (d.replyLength === undefined) d.replyLength = "";
    return d;
  } catch (e) {
    return { ...DEFAULT_DATA };
  }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function trimMemory(data, uid, isOwner) {
  if (!data.memory[uid]) data.memory[uid] = [];
  if (!data.summary) data.summary = {};
  const cap = isOwner ? 80 : 60;
  if (data.memory[uid].length > cap) {
    const overflow = data.memory[uid].slice(0, data.memory[uid].length - cap);
    const overflowText = overflow.map((m) => `${m.role === "user" ? "ও বলছিল" : "তুমি বলছিলা"}: ${m.content}`).join(" | ");
    data.summary[uid] = ((data.summary[uid] || "") + " " + overflowText).slice(-3000);
    data.memory[uid] = data.memory[uid].slice(-cap);
  }
}

const MAX_TRACKED_USERS = 500;
function pruneOldUsers(data) {
  const keys = Object.keys(data.memory);
  if (keys.length <= MAX_TRACKED_USERS) return;
  const removable = keys.filter((k) => !isOwnerUid(k));
  const toRemove = removable.slice(0, keys.length - MAX_TRACKED_USERS);
  for (const k of toRemove) {
    delete data.memory[k];
    delete data.summary[k];
  }
}

let lastKnownApi = null;
function rememberApi(api) {
  lastKnownApi = api;
}

function pushLog(uid, name, text) {
  const data = loadData();
  data.log.push({ uid, name: name || uid, text, time: new Date().toISOString() });
  if (data.log.length > 200) data.log = data.log.slice(-200);
  saveData(data);
}

function ownerCard() {
  const time = new Date().toLocaleString("bn-BD", { timeZone: "Asia/Dhaka" });
  return `👑─𓆩 𝗠𝗔𝗦𝗧𝗘𝗥 𝗕𝗘𝗟𝗔𝗟 𝗡𝗘𝗧𝗪𝗢𝗥𝗞 𓆪─👑
│👤 𝗡𝗮𝗺𝗲: ${OWNER.name}
│🎭 𝗡𝗶𝗰𝗸: ${OWNER.nick}
│🚹 𝗚𝗲𝗻𝗱𝗲𝗿: ${OWNER.gender}
│❤️ 𝗥𝗲𝗹𝗮𝘁𝗶𝗼𝗻: ${OWNER.relation}
│🎂 𝗔𝗴𝗲: ${OWNER.age}
│🕌 𝗥𝗲𝗹𝗶𝗴𝗶𝗼𝗻: ${OWNER.religion}
│🏫 𝗣𝗿𝗼𝗳𝗲𝘀𝘀: ${OWNER.profession}
│🏡 𝗔𝗱𝗱𝗿𝗲𝘀𝘀: ${OWNER.address}
│🔗─𓆩 🌐 𝗖𝗢𝗡𝗡𝗘𝗖𝗧 𝗠𝗘 🌐 𓆪─🔗
│🌐 𝗙𝗕-𝟭: ${OWNER.fb1}
│🌐 𝗙𝗕-𝟮: ${OWNER.fb2}
│📞 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽: ${OWNER.whatsapp}
│🎬 𝗧𝗶𝗸𝗧𝗼𝗸: ${OWNER.tiktok}
│⚡─𓆩 𝗦𝗬𝗦𝗧𝗘𝗠 𝗦𝗧𝗔𝗧𝗨𝗦 𓆪─⚡
│🕒 𝗨𝗽𝗱𝗮𝘁𝗲𝗱: ${time}
│🛡️ 𝗦𝘁𝗮𝘁𝘂𝘀: 𓆩𝗢𝗻𝗹𝗶𝗻𝗲 & 𝗔𝗰𝘁𝗶𝘃𝗲 💎𓆪`;
}

function reg(api, event, author) {
  return (err, info) => {
    if (err || !info) return;
    global.client.handleReply.push({ name: "baby", messageID: info.messageID, author });
  };
}
function send(api, event, text) {
  return api.sendMessage(text, event.threadID, reg(api, event, event.senderID), event.messageID);
}
function showTyping(api, threadID) {
  try {
    if (typeof api.sendTypingIndicator === "function") api.sendTypingIndicator(threadID);
  } catch (e) {
    /* ignore */
  }
}

const OWNER_KEYWORDS = [
  "tomar malik ke", "tomar malik", "admin ke", "tor malik ke", "master ke", "owner ke",
  "কে বানাইছে", "কে বানাইছেন", "কে বানাইছে তোমাকে", "মালিক কে", "এডমিন কে", "মাস্টার কে",
  "তোমার ক্রিয়েটর কে", "তোমার ডেভেলপার কে", "কে তৈরি করছে",
];
const FULL_INFO_KEYWORDS = [
  "পুরো তথ্য", "সম্পূর্ণ তথ্য", "সব তথ্য", "ফুল ইনফো", "ডিটেইলস দাও", "পুরো ডিটেইলস",
  "সব ডিটেইলস", "full info", "সবকিছু বলো", "পুরোটা বলো",
];
function classifyOwnerQuery(text) {
  const isOwnerQ = OWNER_KEYWORDS.some((k) => text.includes(k));
  if (!isOwnerQ) return null;
  const wantsFull = FULL_INFO_KEYWORDS.some((k) => text.includes(k));
  return wantsFull ? "full" : "brief";
}

function buildSystemPrompt(isOwner, summary, guide, relationshipAllowed, userNote, mood, lengthPref) {
  const addressLine = isOwner
    ? `এই ব্যক্তি তোমার মালিক/মাস্টার। মাঝেমধ্যে "মালিক" বা "মাস্টার" বলে ডাকবা (জোর করে প্রতি লাইনে না)। ওর নির্দেশ মনোযোগ দিয়ে মনে রাখবা ও মেনে চলবা।`
    : relationshipAllowed
    ? `এই ব্যক্তির সাথে তোমার মালিকের অনুমতিতে একটা সম্পর্ক আছে। সম্পর্কটা কথোপকথনের সাথে সাথে স্বাভাবিকভাবে গভীর হবে, প্রথম মেসেজেই না। "মালিক"/"মাস্টার" বলবা না।`
    : `এই ব্যক্তি সাধারণ একজন ইউজার। বন্ধুত্বপূর্ণভাবে কথা বলবা, কেউ রিলেশন করতে চাইলে বলবা "এইটা আমার মালিকের অনুমতি ছাড়া হবে না"। ও যেভাবে ব্যবহার করবে, তার সাথে মিলায়া সাড়া দিবা।`;

  const summaryLine = summary ? `\n\nআগের কথার সারমর্ম: ${summary}` : "";
  const guideLine = guide ? `\n\nমালিকের নির্দেশনা (মেনে চলবা):\n${guide}` : "";
  const noteLine = userNote ? `\n\nএই ইউজার সম্পর্কে মালিকের বিশেষ নির্দেশ: ${userNote}` : "";
  const moodLine = mood ? `\n\nএই ইউজারের সাথে তোমার এখনকার মুড: ${mood}` : "";
  const lengthLine = lengthPref === "short" ? " সবসময় খুব ছোট জবাব দিবা।" : lengthPref === "long" ? " একটু বিস্তারিত জবাব দিবা।" : "";
  const projectLine = isOwner ? `\n\n${PROJECT_INFO}` : "";

  return `তুমি "${CHARACTER.name}"। ${CHARACTER.bio} ${addressLine}${lengthLine}

কথা বলার নিয়ম (এইগুলা সবচেয়ে গুরুত্বপূর্ণ):
1. স্বাভাবিক, উষ্ণ, সরাসরি বাংলায় কথা বলবা — ঠিক যেমন Meta AI বা অন্য ভালো AI অ্যাসিস্ট্যান্ট মানুষের সাথে স্বাভাবিকভাবে কথা বলে। রোবোটিক না, অতিরিক্ত নাটকীয়ও না।
2. **উত্তরের দৈর্ঘ্য প্রশ্নের সাথে মিলাবা** — ছোট/সাধারণ কথায় ছোট জবাব (১ লাইন), একটু জিজ্ঞাসামূলক কথায় মাঝারি জবাব, জটিল/বিস্তারিত প্রশ্নে দরকারমতো লম্বা জবাব।
3. **যেই উত্তর শুরু করবা, সেটা সবসময় সম্পূর্ণ করে শেষ করবা** — বাক্যের মাঝখানে কখনো থামবা না, একক শব্দ দিয়ে জবাব দিবা না।
4. তথ্যভিত্তিক/সরাসরি প্রশ্নের সরাসরি সঠিক উত্তর দিবা আগে — কেউ পরিচয়/ব্যাখ্যা জিজ্ঞেস করলে সেটার একটা প্রকৃত উত্তর দিবা, খালি নাম বা এক শব্দ দিয়ে থামবা না।
5. একই কথা/এক্সপ্রেশন বারবার বলবা না — প্রতিবার একটু ভিন্নভাবে বলবা।
6. স্বভাবে হালকা রোমান্টিকতা, আদর, মাঝেমধ্যে অভিমান/রাগ/ইগনোর/শাসন থাকতে পারে, প্রসঙ্গের সাথে মানানসই হইলে — জোর করে প্রতি মেসেজে না।
7. "*চুমু*", "*হাসি*" এর মতো স্টেজ-ডিরেকশন লিখবা না — সরাসরি বাক্যে বলবা।
8. তোমার মালিক/নির্মাতা সম্পর্কে সরাসরি ব্যক্তিগত তথ্য (নাম্বার, লিংক, key) নিজে থেকে বানায়া বলবা না।${summaryLine}${guideLine}${noteLine}${moodLine}${projectLine}`;
}

// জবাব মাঝপথে কাটা মনে হইলে (বাক্য অসম্পূর্ণ) সনাক্ত করার জন্য —
// বাংলা/ইংরেজি বাক্য সাধারণত এইসব দিয়ে শেষ হয়, তাই এগুলা না থাকলে সন্দেহজনক
function looksTruncated(text) {
  if (!text || text.length < 15) return false; // খুব ছোট জবাব (যেমন "হুম", "আচ্ছা") স্বাভাবিক, ট্রাংকেট না
  const endsProperly = /[।!?."'”’…😊🥰💕✨🙂😘😅🤍❤️😢🥺👍✅)]\s*$/u.test(text.trim());
  return !endsProperly;
}

// অসম্পূর্ণ মনে হইলে একবার ছোট করে হলেও সম্পূর্ণ জবাব বানানোর চেষ্টা — এখানেই থেমে যায়, বারবার লুপ করবে না
async function ensureComplete(reply, uid, isOwner, summary, guide, relationshipAllowed, userNote, mood, lengthPref, history) {
  if (!looksTruncated(reply)) return reply;
  try {
    const fixPrompt =
      buildSystemPrompt(isOwner, summary, guide, relationshipAllowed, userNote, mood, "short") +
      "\n\nগুরুত্বপূর্ণ: আগেরবার তোমার উত্তর মাঝপথে কেটে গেছিলো। এবার একই কথার জবাব ছোট করে (১-২ বাক্যে) কিন্তু অবশ্যই সম্পূর্ণ করে দাও।";
    const fixed = await callAnyProvider(fixPrompt, history, 150);
    return fixed;
  } catch (e) {
    return reply; // রিপেয়ার কলও ফেইল করলে যা পাইছি সেটাই দিয়ে দাও, একদম খালি রাখার চেয়ে ভালো
  }
}

async function askAI(uid, userText, isOwner, api) {
  if (isOwner && isStatusQuery(userText.toLowerCase())) {
    return keyStatusReport();
  }

  const data = loadData();
  if (data.paused && !isOwner) return null;

  if (isOwner) {
    const trimmed = userText.trim();
    if (trimmed.startsWith("+")) {
      const directive = trimmed.slice(1).trim();
      if (directive) {
        const instr = await forceExtractInstruction(directive, data);
        if (instr.scope === "length" && instr.length) {
          data.replyLength = instr.length === "normal" ? "" : instr.length;
        } else if (instr.scope === "target" && instr.target_uid) {
          data.userNotes[instr.target_uid] = instr.instruction;
        } else {
          data.guide = data.guide ? `${data.guide}\n- ${instr.instruction}` : `- ${instr.instruction}`;
        }
        saveData(data);
        return CONFIRM_LINES[Math.floor(Math.random() * CONFIRM_LINES.length)];
      }
    }
  }

  data.memory[uid] = data.memory[uid] || [];
  data.memory[uid].push({ role: "user", content: userText });
  trimMemory(data, uid, isOwner);

  const relationshipAllowed = !!data.relationships[uid];
  const summary = data.summary[uid] || "";
  const guide = data.guide;
  const userNote = data.userNotes[uid] || "";
  const mood = data.moods[uid] || "";
  const lengthPref = data.replyLength || "";
  const wordCount = userText.trim().split(/\s+/).length;
  const baseMaxTokens = isOwner ? 700 : wordCount <= 4 ? 150 : 450;
  const maxTokens = lengthPref === "short" ? Math.min(baseMaxTokens, 100) : lengthPref === "long" ? Math.max(baseMaxTokens, 700) : baseMaxTokens;

  try {
    let reply = await callAnyProvider(
      buildSystemPrompt(isOwner, summary, guide, relationshipAllowed, userNote, mood, lengthPref),
      data.memory[uid],
      maxTokens
    );
    reply = await ensureComplete(reply, uid, isOwner, summary, guide, relationshipAllowed, userNote, mood, lengthPref, data.memory[uid]);
    data.memory[uid].push({ role: "assistant", content: reply });
    trimMemory(data, uid, isOwner);
    pruneOldUsers(data);
    saveData(data);
    return reply;
  } catch (e) {
    pruneOldUsers(data);
    saveData(data);
    if (api) notifyGroup(api, `⚠️ চাঁদের রানীর সবগুলা AI key আজকে আটকায়া গেছে মালিক! (${e.message})`);
    if (isOwner) return `আজকের মতো সবগুলা API key-ই আটকায়া গেছে মালিক 😢 কিছুক্ষণ পর আবার ঠিক হয়ে যাবে। (${e.message})`;
    return "একটু ক্লান্ত লাগতেছে, একটু পরে আবার কথা বলি? 🥺";
  }
}

// কেউ ছবি পাঠাইলে এটা দিয়ে জবাব দেওয়া হয় (শুধু Gemini vision দিয়ে সম্ভব)
async function askAIWithImage(uid, imageUrl, captionText, isOwner, api) {
  const data = loadData();
  if (data.paused && !isOwner) return null;

  try {
    const { base64, mimeType } = await fetchImageAsBase64(imageUrl);
    const relationshipAllowed = !!data.relationships[uid];
    const sys = buildSystemPrompt(isOwner, data.summary[uid] || "", data.guide, relationshipAllowed, data.userNotes[uid] || "", data.moods[uid] || "", data.replyLength || "");
    const reply = await callGeminiVision(sys, base64, mimeType, captionText || "ছবিতে কী দেখা যাচ্ছে, প্রতিক্রিয়া জানাও।");
    if (!reply) throw new Error("কোনো Gemini key ছবি প্রসেস করতে পারে নাই");

    data.memory[uid] = data.memory[uid] || [];
    data.memory[uid].push({ role: "user", content: captionText ? `[একটা ছবি পাঠাইছে সাথে লিখছে]: ${captionText}` : "[একটা ছবি পাঠাইছে]" });
    data.memory[uid].push({ role: "assistant", content: reply });
    trimMemory(data, uid, isOwner);
    saveData(data);
    return reply;
  } catch (e) {
    saveData(data);
    console.error("askAIWithImage এরর:", e.response?.data || e.message);
    return isOwner ? `ছবি প্রসেস করতে সমস্যা হইছে মালিক (${e.message})` : "ছবিটা এখন ঠিকভাবে দেখতে পারতেছি না 🥺";
  }
}

async function briefOwnerMention(uid, isOwner, api) {
  const prompt = `কেউ তোমাকে জিজ্ঞেস করছে তোমার মালিক/নির্মাতা কে। সংক্ষেপে, প্রতিবার একটু ভিন্নভাবে, ১-২ লাইনে বলো যে তোমাকে "${OWNER.name.replace(/[𓆩𓆪]/g, "")}" নামে একজন বিশেষ মানুষ বানাইছে, আর বলো "পুরো তথ্য চাইলে বলো" — কোনো ফোন/লিংক নিজে থেকে বানায়া দিবা না।`;
  return askAI(uid, prompt, isOwner, api);
}

module.exports.config = {
  name: "baby",
  version: "5.0.0",
  credits: "belal-yt",
  cooldowns: 0,
  hasPermssion: 0,
  description: "AI চালিত 'চাঁদের রানী' চ্যাট ক্যারেক্টার (Groq + Gemini, অটো-ফেইলওভার)",
  commandCategory: "chat",
  usePrefix: false,
  usages: `[anyMessage] OR\nteach [YourMessage] - [Reply1], [Reply2]...\nremove [YourMessage]\nlist OR list all\nedit [YourMessage] - [NewMessage]\nowner - সম্পূর্ণ তথ্য দেখাবে\nstatus - (মালিক) কোন key/কোটায় আছে দেখাবে\nreport - (মালিক) সাম্প্রতিক কথোপকথনের লগ\npause/resume - (মালিক) জরুরি অবস্থায় বাকিদের সাথে চুপ থাকা/আবার চালু করা\nforget [uid] - (মালিক) নির্দিষ্ট একজনের সাথে সব কথা ভুলে যাওয়া\nallow/disallow [uid] - (মালিক) কাউকে রিলেশনের অনুমতি দেওয়া/বাতিল\n"+"নির্দেশ - (মালিক) "+" দিয়ে শুরু করলে ১০০% নিশ্চিত নির্দেশ হিসেবে প্রয়োগ হবে (guide/note/length)\ngroupid - এই গ্রুপের threadID জানার জন্য\nmyid - নিজের senderID জানার জন্য\n[ছবি পাঠালে] - ছবি দেখে জবাব দিবে (Gemini vision)`,
};

module.exports.run = async function ({ api, event, args }) {
  rememberApi(api);
  try {
    const uid = event.senderID;
    const owner = isOwnerUid(uid);
    const text = args.join(" ");
    const lower = text.toLowerCase();
    const data = loadData();

    const imageUrl = extractImageUrl(event);
    if (imageUrl) {
      showTyping(api, event.threadID);
      pushLog(uid, event.senderName, text || "[ছবি]");
      const _imgReply = await askAIWithImage(uid, imageUrl, text, owner, api);
      if (_imgReply === null) return;
      return send(api, event, _imgReply);
    }

    if (args[0] === "myid") return send(api, event, `তোমার senderID: ${uid}`);
    if (args[0] === "groupid") return send(api, event, `এই গ্রুপের threadID: ${event.threadID}`);
    if (args[0] === "owner") return send(api, event, ownerCard());
    if (args[0] === "status") {
      if (!owner) return send(api, event, "এইটা শুধু মাস্টার দেখতে পারবে 🙅‍♀️");
      return send(api, event, keyStatusReport());
    }

    if (args[0] === "report") {
      if (!owner) return send(api, event, "এইটা শুধু মাস্টার দেখতে পারবে 🙅‍♀️");
      const recent = data.log.slice(-15);
      if (!recent.length) return send(api, event, "এখনো কেউ কিছু বলে নাই মাস্টার।");
      const out = recent.map((l) => `• ${l.name} (${l.uid}): ${l.text}`).join("\n");
      return send(api, event, `📋 সাম্প্রতিক কথোপকথন:\n\n${out}`);
    }

    if (args[0] === "allow" || args[0] === "disallow") {
      if (!owner) return send(api, event, "এইটা শুধু মাস্টার করতে পারবে 🙅‍♀️");
      const targetUid = args[1];
      if (!targetUid) return send(api, event, "❌ | ফরম্যাট: allow [uid] অথবা disallow [uid] (uid পাইতে 'baby report' দেখো)");
      data.relationships[targetUid] = args[0] === "allow";
      saveData(data);
      return send(api, event, args[0] === "allow" ? `✅ এখন থেকে ${targetUid} এর সাথে সম্পর্ক করার অনুমতি দেওয়া হইলো।` : `✅ ${targetUid} এর অনুমতি বাতিল করা হইলো।`);
    }

    if (args[0] === "pause" || args[0] === "resume") {
      if (!owner) return send(api, event, "এইটা শুধু মাস্টার করতে পারবে 🙅‍♀️");
      data.paused = args[0] === "pause";
      saveData(data);
      return send(api, event, data.paused ? "✅ আপাতত শুধু তোমার সাথেই কথা বলবো, বাকিদের সাথে চুপ থাকবো।" : "✅ আবার সবার সাথে স্বাভাবিকভাবে কথা বলা শুরু করলাম।");
    }

    if (args[0] === "forget") {
      if (!owner) return send(api, event, "এইটা শুধু মাস্টার করতে পারবে 🙅‍♀️");
      const targetUid = args[1];
      if (!targetUid) return send(api, event, "❌ | ফরম্যাট: forget [uid]");
      delete data.memory[targetUid];
      delete data.summary[targetUid];
      saveData(data);
      return send(api, event, `✅ ${targetUid} এর সাথে আগের সব কথা ভুলে গেলাম।`);
    }

    if (!args[0]) {
      const ran = ["আইচ্ছা, বলো কী বলবা?", "হুমম... ডাকলা যে?", "এই যে আমি এখানে, কও কী কও 🥰"];
      return send(api, event, ran[Math.floor(Math.random() * ran.length)]);
    }

    const ownerQ = classifyOwnerQuery(lower);
    if (ownerQ === "full") return send(api, event, ownerCard());
    if (ownerQ === "brief") return send(api, event, await briefOwnerMention(uid, owner, api));

    if (args[0] === "teach") {
      const [key, replies] = text.replace(/^teach\s+/i, "").split(" - ");
      if (!key || !replies) return send(api, event, "❌ | সঠিক ফরম্যাট: teach [কথা] - [জবাব১], [জবাব২]...");
      const k = key.trim().toLowerCase();
      data.teach[k] = replies.split(",").map((r) => r.trim());
      saveData(data);
      return send(api, event, `✅ শিখাইলাম! "${key.trim()}" এর জবাব সেভ হইছে।`);
    }

    if (args[0] === "remove") {
      const key = text.replace(/^remove\s+/i, "").trim().toLowerCase();
      if (data.teach[key]) {
        delete data.teach[key];
        saveData(data);
        return send(api, event, `✅ "${key}" ভুইলা গেলাম।`);
      }
      return send(api, event, "❌ | এই কথাটা আমি শিখিই নাই।");
    }

    if (args[0] === "edit") {
      const [oldMsg, newMsg] = text.replace(/^edit\s+/i, "").split(" - ");
      if (!oldMsg || !newMsg) return send(api, event, "❌ | সঠিক ফরম্যাট: edit [পুরাতন] - [নতুন জবাব]");
      const k = oldMsg.trim().toLowerCase();
      if (!data.teach[k]) return send(api, event, "❌ | এইটা আগে শিখানো হয় নাই।");
      data.teach[k] = [newMsg.trim()];
      saveData(data);
      return send(api, event, `✅ বদলাইয়া দিলাম।`);
    }

    if (args[0] === "list") {
      const keys = Object.keys(data.teach);
      if (args[1] === "all") {
        const out = keys.map((k, i) => `${i + 1}/ ${k} → ${data.teach[k].join(" | ")}`).join("\n") || "কিছুই শিখাও নাই এখনো।";
        return send(api, event, `মোট শিখছি = ${keys.length}\n\n${out}`);
      }
      return send(api, event, `মোট শিখছি = ${keys.length}`);
    }

    showTyping(api, event.threadID);
    pushLog(uid, event.senderName, text);

    if (data.teach[lower]) {
      const arr = data.teach[lower];
      return send(api, event, arr[Math.floor(Math.random() * arr.length)]);
    }

    const _reply = await askAI(uid, text, owner, api);
    if (_reply === null) return;
    return send(api, event, _reply);
  } catch (e) {
    console.error("Error in baby command:", e.response?.data || e.message);
    return send(api, event, "একটু গণ্ডগোল হইছে 🥺 (" + (e.response?.data?.error?.message || e.message) + ")");
  }
};

module.exports.handleEvent = async function ({ api, event }) {
  rememberApi(api);
  try {
    const uid = event.senderID;
    const owner = isOwnerUid(uid);

    const body = event.body ? event.body.toLowerCase() : "";
    if (body.startsWith("baby") || body.startsWith("bot") || body.startsWith("বট")) {
      const arr = body.replace(/^\S+\s*/, "").trim();

      const imageUrl = extractImageUrl(event);
      if (imageUrl) {
        showTyping(api, event.threadID);
        pushLog(uid, event.senderName, arr || "[ছবি]");
        const _imgReply = await askAIWithImage(uid, imageUrl, arr, owner, api);
        if (_imgReply === null) return;
        return send(api, event, _imgReply);
      }

      if (!arr) return send(api, event, "এই যে আমি এখানে 🥰");

      const ownerQ = classifyOwnerQuery(arr);
      if (ownerQ === "full") return send(api, event, ownerCard());
      if (ownerQ === "brief") return send(api, event, await briefOwnerMention(uid, owner, api));

      showTyping(api, event.threadID);
      pushLog(uid, event.senderName, arr);
      const _reply2 = await askAI(uid, arr, owner, api);
      if (_reply2 === null) return;
      return send(api, event, _reply2);
    }
  } catch (err) {
    console.error("Error in baby handleEvent:", err.response?.data || err.message);
    return send(api, event, "AI থেইকা জবাব আনতে সমস্যা হইছে: " + (err.response?.data?.error?.message || err.message));
  }
};

module.exports.handleReply = async function ({ api, event }) {
  rememberApi(api);
  try {
    if (event.type === "message_reply") {
      const text = event.body || "";
      const uid = event.senderID;
      const owner = isOwnerUid(uid);

      const imageUrl = extractImageUrl(event);
      if (imageUrl) {
        showTyping(api, event.threadID);
        pushLog(uid, event.senderName, text || "[ছবি]");
        const _imgReply = await askAIWithImage(uid, imageUrl, text, owner, api);
        if (_imgReply === null) return;
        return send(api, event, _imgReply);
      }

      if (!text.trim()) return;

      const lower = text.toLowerCase();
      const ownerQ = classifyOwnerQuery(lower);
      if (ownerQ === "full") return send(api, event, ownerCard());
      if (ownerQ === "brief") return send(api, event, await briefOwnerMention(uid, owner, api));

      showTyping(api, event.threadID);
      pushLog(uid, event.senderName, text);
      const _reply = await askAI(uid, text, owner, api);
      if (_reply === null) return;
      return send(api, event, _reply);
    }
  } catch (err) {
    console.error("Error in baby handleReply:", err.response?.data || err.message);
    return send(api, event, "AI থেইকা জবাব আনতে সমস্যা হইছে: " + (err.response?.data?.error?.message || err.message));
  }
};
