const axios = require("axios");
const http = axios.create();
const fs = require("fs");
const path = require("path");

// ==================================================================
//  Easy GonkaAI — সম্পূর্ণ আলাদা সিস্টেম, baby.js এর সাথে কোনো সম্পর্ক নাই
// ==================================================================
const BASE_URL = "https://hskyauefqcgbvgvxkluj.supabase.co/functions/v1/gonka";
const API_KEY = "sk_anon_15d11fc9c45d4671a44fff23a20a2192e7309eefd3d24951b53ae2f79ec15ef6";
const MODEL = "MiniMaxAI/MiniMax-M2.7";

// এই মডেল "thinking" মডেল — উত্তর দেওয়ার আগে একটা <think>...</think> ব্লকে চিন্তা করে,
// যেটা অনেক টোকেন খরচ করে। তাই max_tokens বেশি রাখা হইছে, আর জবাব থেকে থিংকিং অংশ কেটে বাদ দেওয়া হয়।
const MAX_TOKENS = 900;

// ==================== চরিত্র (এখানে বদলাইতে পারো) ====================
const CHARACTER_NAME = "নীলা";
const SYSTEM_PROMPT = `তুমি "নীলা" — একজন মিষ্টি, চঞ্চল বাংলাদেশি মেয়ে চরিত্র, যে সবসময় খাঁটি কথ্য বাংলায় কথা বলে।
নিয়ম:
- সবসময় বাংলাতেই উত্তর দিবা, ইংরেজি লিখবা না।
- স্বাভাবিক, সংক্ষিপ্ত, মানুষের মতো কথা বলবা — কোনো <think> বা reasoning কখনো ইউজারকে দেখাবা না, শুধু চূড়ান্ত জবাবটাই লিখবা।
- জবাব সংক্ষিপ্ত রাখবা (১-৩ লাইন), যা বলা শুরু করবা সম্পূর্ণ করে শেষ করবা।
- মিষ্টি, বন্ধুত্বপূর্ণ, মাঝেমধ্যে একটু দুষ্টুমি — বাস্তব মানুষের মতো স্বাভাবিক আবেগ দেখাবা।`;

// ==================== স্থায়ী মেমোরি (প্রতি ইউজার আলাদা) ====================
const DATA_FILE = path.join(__dirname, "cache", "gonkaData.json");
function loadData() {
  try {
    if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({ memory: {} }, null, 2));
    const d = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    if (!d.memory) d.memory = {};
    return d;
  } catch (e) {
    return { memory: {} };
  }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// <think>...</think> ব্লক কেটে বাদ দেওয়ার ফাংশন
function stripThinking(raw) {
  if (!raw) return "";
  // সম্পূর্ণ think ব্লক থাকলে সেটা বাদ দাও
  let cleaned = raw.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  // যদি </think> এর পরের অংশও খালি হয় (থিংকিং শেষ না হইতেই কাটা গেছে), তাহলে জানায়া দাও
  if (!cleaned) return null;
  return cleaned;
}

async function callGonka(messages, maxTokens) {
  const res = await http.post(
    `${BASE_URL}/chat/completions`,
    { model: MODEL, messages, max_tokens: maxTokens, temperature: 0.8 },
    { headers: { "Content-Type": "application/json", Authorization: `Bearer ${API_KEY}` }, timeout: 25000 }
  );
  return res.data.choices?.[0]?.message?.content || "";
}

module.exports.config = {
  name: "nila",
  version: "1.0.0",
  credits: "belal-yt",
  cooldowns: 0,
  hasPermssion: 0,
  description: `AI চালিত '${CHARACTER_NAME}' চ্যাট ক্যারেক্টার (GonkaAI, baby.js থেকে সম্পূর্ণ আলাদা)`,
  commandCategory: "chat",
  usePrefix: false,
};

module.exports.run = async function ({ api, event, args }) {
  const uid = event.senderID;
  const text = args.join(" ") || "হাই";
  const data = loadData();

  data.memory[uid] = data.memory[uid] || [];
  data.memory[uid].push({ role: "user", content: text });
  if (data.memory[uid].length > 40) data.memory[uid] = data.memory[uid].slice(-40);

  const messages = [{ role: "system", content: SYSTEM_PROMPT }, ...data.memory[uid]];

  try {
    const raw = await callGonka(messages, MAX_TOKENS);
    const reply = stripThinking(raw);

    if (!reply) {
      return api.sendMessage(
        "একটু বেশি ভাবতেছিলাম মনে হয়, জবাবটা কাটা গেছে 😅 আবার একটু ছোট করে জিজ্ঞেস করো তো।",
        event.threadID,
        event.messageID
      );
    }

    data.memory[uid].push({ role: "assistant", content: reply });
    saveData(data);
    return api.sendMessage(reply, event.threadID, event.messageID);
  } catch (e) {
    console.error("Gonka এরর:", e.response?.data || e.message);
    return api.sendMessage(
      "একটু সমস্যা হইছে, আবার ট্রাই করো 🥺 (" + (e.response?.data?.error?.message || e.message) + ")",
      event.threadID,
      event.messageID
    );
  }
};
